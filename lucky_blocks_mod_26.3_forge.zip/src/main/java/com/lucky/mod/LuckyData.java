package com.lucky.mod;

/** 100 loot bonus, 100 loot malus, 40 evenements classiques, 90 evenements legendaires. */
public class LuckyData {
    // 26.x : composants d'objets (plus de NBT "tag")
    static String E(String s) { return "{\"minecraft:enchantments\":" + L(s) + "}"; }
    static String B(String s) { return "enchanted_book*1*{\"minecraft:stored_enchantments\":" + L(s) + "}"; }
    private static String L(String s) {
        StringBuilder b = new StringBuilder("{");
        String[] p = s.split(",");
        for (int i = 0; i < p.length; i++) {
            String[] kv = p[i].split(":");
            if (i > 0) b.append(',');
            b.append("\"minecraft:").append(kv[0]).append("\":").append(kv[1]);
        }
        return b.append('}').toString();
    }
    static String N(String id, String name) { return id + "*1*{\"minecraft:custom_name\":\"" + name + "\"}"; }
    static String P(String potion) { return "potion*1*{\"minecraft:potion_contents\":{potion:\"minecraft:" + potion + "\"}}"; }
    static String[] ev(String... s) { return s; }
    static String S(String id) { return "place structure minecraft:" + id; }
    static final String ANVIL_RAIN = "REP:20:7:summon falling_block {x} ~16 {z} {block_state:{Name:\"minecraft:anvil\"},hurt_entities:1b,fall_hurt_amount:2.0f,fall_hurt_max:40,time:1}";
    static final String CT = "execute align xyz positioned ~0.5 ~ ~0.5 run tp @p ~ ~ ~";
    static final String LEATHER = "{\"minecraft:dyed_color\":16711935}";

    // ===================== 100 LOOTS BONUS =====================
    static final String[] BONUS = {
        "sponge*1", "diamond*8", "emerald*16", "gold_ingot*32", "iron_ingot*32", "copper_ingot*32", "netherite_scrap*2", "ancient_debris*1", "diamond_block*1", "emerald_block*1",
        "gold_block*2", "iron_block*4", "coal*64", "lapis_lazuli*32", "redstone*64", "quartz*32", "amethyst_block*16", "amethyst_shard*32", "echo_shard*2", "disc_fragment_5*4",
        "wet_sponge*1", "saddle*1", "name_tag*3", "bell*1", "egg*16", "tropical_fish_bucket*1", "cod_bucket*1", "goat_horn*1*{\"minecraft:instrument\":\"minecraft:ponder_goat_horn\"}", "music_disc_cat*1", "creeper_head*1",
        "carrot*32", "potato*64", "golden_apple*3", "enchanted_golden_apple*1", "cake*3", "pumpkin_pie*16", "cooked_beef*32", "golden_carrot*16", "glow_berries*32", "honey_bottle*8",
        "diamond_sword*1", "diamond_pickaxe*1", "diamond_axe*1", "diamond_shovel*1", "bow*1*" + E("power:4,unbreaking:3"), "crossbow*1*" + E("quick_charge:3,unbreaking:3"), "trident*1", "shield*1",
        "diamond_helmet*1|diamond_chestplate*1|diamond_leggings*1|diamond_boots*1",
        "golden_helmet*1|golden_chestplate*1|golden_leggings*1|golden_boots*1",
        "iron_helmet*1|iron_chestplate*1|iron_leggings*1|iron_boots*1", "diamond_boots*1*" + E("feather_falling:4,depth_strider:3"), "elytra*1", "turtle_helmet*1", "enchanted_golden_apple*2",
        B("mending:1"), B("fortune:3"), B("efficiency:5"), B("protection:4"), B("looting:3"),
        "totem_of_undying*1", "ender_pearl*16", "ender_eye*8", "heart_of_the_sea*1", "nautilus_shell*8", "conduit*1", "nether_star*1", "dragon_egg*1", "end_crystal*1", "prismarine_shard*32",
        "sea_lantern*16", "sponge*8", "compass*1", "recovery_compass*1", "map*1", "map*1", "saddle*3", "diamond_horse_armor*1", "music_disc_5*1", "globe_banner_pattern*1",
        "flower_pot*16", "item_frame*16", "glow_item_frame*8", "oak_sign*32", "candle*32", "bell*16", "white_banner*8", "white_carpet*16|red_carpet*16", "lily_pad*32", "cobweb*16",
        "scaffolding*64", "melon_seeds*32", "pumpkin_seeds*32", "red_mushroom*32", "brown_mushroom*32", "writable_book*1", "clock*1", "lead*8", "powder_snow_bucket*1", "turtle_egg*4"
    };

    // ===================== 100 LOOTS MALUS =====================
    static final String[] MALUS = {
        "dirt*64", "coarse_dirt*32", "gravel*64", "sand*64", "red_sand*64", "netherrack*64", "andesite*64", "diorite*64", "granite*64", "deepslate*64",
        "stone*64", "cobblestone*64", "stone_bricks*64", "terracotta*32", "clay*32", "snow_block*32", "ice*32", "packed_ice*16", "basalt*64", "crying_obsidian*4",
        "poisonous_potato*32", "rotten_flesh*64", "spider_eye*16", "pufferfish*16", "sweet_berries*64", "beetroot*64", "wheat_seeds*64", "melon_seeds*32", "pumpkin_seeds*32", "snowball*16",
        "bone*64", "string*64", "feather*64", "stick*64", "ink_sac*32", "glow_ink_sac*16", "glass_bottle*32", "bucket*8", "beetroot_seeds*64", "shulker_shell*1",
        "wooden_sword*1", "wooden_pickaxe*1", "wooden_shovel*1", "wooden_axe*1", "wooden_hoe*1", "leather_helmet*1", "leather_chestplate*1", "leather_leggings*1", "leather_boots*1", "golden_sword*1",
        "golden_pickaxe*1", "golden_helmet*1|golden_chestplate*1|golden_leggings*1|golden_boots*1", "bow*1*{\"minecraft:damage\":380}", "fishing_rod*1", "shield*1*{\"minecraft:damage\":330}", "stone_hoe*1", "crossbow*1", "trident*1*{\"minecraft:damage\":240}", "leather_boots*1*" + E("sharpness:5"),
        "leather_helmet*1*" + LEATHER + "|leather_chestplate*1*" + LEATHER + "|leather_leggings*1*" + LEATHER + "|leather_boots*1*" + LEATHER,
        "cobweb*64", "oak_sign*64", "oak_door*32", "oak_trapdoor*32", "oak_button*64", "oak_pressure_plate*32", "rail*64", "detector_rail*32", "powered_rail*16", "minecart*16",
        "oak_boat*16", "barrel*32", "composter*16", "scaffolding*64", "white_carpet*64", "flower_pot*32", "item_frame*32", "clock*16", "compass*16", "milk_bucket*8",
        B("vanishing_curse:1"), B("binding_curse:1"), "diamond_chestplate*1*" + E("binding_curse:1"), "diamond_helmet*1*" + E("vanishing_curse:1"), "diamond_sword*1*" + E("vanishing_curse:1"),
        "diamond_pickaxe*1*" + E("vanishing_curse:1"), "bow*1*" + E("vanishing_curse:1"), B("bane_of_arthropods:1"), P("slowness"), P("weakness"),
        P("poison"), P("harming"), "potion*1*{\"minecraft:potion_contents\":{custom_effects:[{id:\"minecraft:unluck\",duration:6000}],custom_color:8889187}}", "redstone*64",
        N("rotten_flesh", "Diamant"), N("potato", "Netherite"), N("coal", "\u00c9meraude"), N("stone", "Or"), N("stick", "\u00c9p\u00e9e l\u00e9gendaire"), "chest*1"
    };

    // ===================== 40 EVENEMENTS CLASSIQUES =====================
    static final String[][] CLASSIC = {
        ev(CT, "fill ~-1 ~-1 ~-1 ~1 ~7 ~1 stone_bricks hollow", "setblock ~ ~7 ~ air", "setblock ~ ~11 ~ anvil"),
        ev("fill ~-1 ~12 ~-1 ~1 ~14 ~1 gravel"),
        ev("fill ~-1 ~12 ~-1 ~1 ~12 ~1 pointed_dripstone[vertical_direction=down]"),
        ev("setblock ~2 ~ ~ piston[facing=west]", "setblock ~3 ~ ~ redstone_block", "setblock ~-2 ~ ~ piston[facing=east]", "setblock ~-3 ~ ~ redstone_block",
           "setblock ~2 ~1 ~ piston[facing=west]", "setblock ~3 ~1 ~ redstone_block", "setblock ~-2 ~1 ~ piston[facing=east]", "setblock ~-3 ~1 ~ redstone_block"),
        ev(CT, "fill ~-1 ~-1 ~-1 ~1 ~2 ~1 glass hollow"),
        ev(CT, "fill ~-1 ~-1 ~-1 ~1 ~2 ~1 obsidian hollow"),
        ev(CT, "fill ~-1 ~-1 ~-1 ~1 ~3 ~1 glass hollow", "fill ~ ~ ~ ~ ~2 ~ water"),
        ev("fill ~-1 ~4 ~-1 ~1 ~4 ~1 sand"),
        ev("fill ~-2 ~-1 ~-2 ~2 ~-1 ~2 air"),
        ev("fill ~-3 ~-8 ~-3 ~3 ~-3 ~3 stone_bricks hollow", "fill ~-1 ~-3 ~-1 ~1 ~-1 ~1 air", "setblock ~2 ~-7 ~2 chest{LootTable:\"minecraft:chests/simple_dungeon\"}"),
        ev("fill ~-1 ~ ~-1 ~1 ~2 ~1 cobweb"),
        ev("fill ~-1 ~ ~-1 ~1 ~2 ~1 powder_snow"),
        ev(CT, "fill ~-4 ~-1 ~-4 ~4 ~3 ~4 stone_bricks hollow", "setblock ~-4 ~ ~ redstone_block", "setblock ~-3 ~ ~ sticky_piston[facing=east]",
           "setblock ~-4 ~1 ~ redstone_block", "setblock ~-3 ~1 ~ sticky_piston[facing=east]"),
        ev("setblock ~2 ~ ~ trapped_chest{Items:[{Slot:13b,id:\"minecraft:diamond\",count:3}]}", "setblock ~2 ~-1 ~ tnt"),
        ev("CHEST:2,0,0:diamond*5|emerald*8", "summon tnt ~3 ~ ~ {fuse:70}", "summon tnt ~2 ~ ~2 {fuse:70}", "summon tnt ~2 ~ ~-2 {fuse:70}", "summon tnt ~1 ~ ~ {fuse:70}"),
        ev(S("ruined_portal")),
        ev("REP:6:3:summon oak_boat {x} ~12 {z}"),
        ev("REP:5:3:summon falling_block {x} ~12 {z} {block_state:{Name:\"minecraft:chest\"},TileEntityData:{LootTable:\"minecraft:chests/simple_dungeon\"},time:1}"),
        ev("REP:12:3:summon chicken {x} ~10 {z}"),
        ev("REP:10:4:summon sheep {x} ~ {z}"),
        ev("REP:6:4:summon zombie {x} ~ {z}"),
        ev("REP:4:5:summon pillager {x} ~ {z}"),
        ev("summon creeper ~ ~ ~2"),
        ev("REP:8:4:summon slime {x} ~ {z} {Size:1}"),
        ev("REP:5:4:summon spider {x} ~ {z}"),
        ev("summon guardian ~3 ~ ~"),
        ev("summon enderman ~3 ~ ~"),
        ev("summon wandering_trader ~3 ~ ~", "summon trader_llama ~4 ~ ~", "summon trader_llama ~4 ~ ~2"),
        ev("summon cow ~2 ~ ~", "summon pig ~-2 ~ ~", "summon sheep ~ ~ ~2", "summon chicken ~ ~ ~-2", "summon horse ~3 ~ ~3", "summon llama ~-3 ~ ~3", "summon cat ~3 ~ ~-3", "summon wolf ~-3 ~ ~-3", "summon rabbit ~1 ~ ~1", "summon fox ~-1 ~ ~-1"),
        ev("REP:4:4:summon witch {x} ~ {z}"),
        ev("fill ~ ~-1 ~ ~ ~14 ~ dirt", "tp @p ~ ~15 ~"),
        ev("fill ~-1 ~-1 ~-1 ~1 ~-8 ~1 air"),
        ev("fill ~3 ~ ~-2 ~7 ~1 ~2 netherrack", "fill ~4 ~2 ~-1 ~6 ~3 ~1 netherrack", "setblock ~5 ~3 ~ lava", "setblock ~5 ~4 ~ lava"),
        ev(S("village_plains"), "kill @e[type=villager,distance=..120]"),
        ev("fill ~3 ~-1 ~-1 ~5 ~0 ~1 sandstone", "setblock ~4 ~0 ~0 water", "fill ~3 ~1 ~-1 ~5 ~3 ~1 air", "setblock ~3 ~1 ~-1 sandstone_wall", "setblock ~5 ~1 ~-1 sandstone_wall", "setblock ~3 ~1 ~1 sandstone_wall", "setblock ~5 ~1 ~1 sandstone_wall", "fill ~3 ~2 ~-1 ~5 ~2 ~1 sandstone_slab"),
        ev("fill ~3 ~-1 ~3 ~7 ~3 ~7 oak_planks hollow", "setblock ~3 ~ ~5 air", "setblock ~3 ~1 ~5 air", "setblock ~5 ~ ~5 chest{LootTable:\"minecraft:chests/village/village_weaponsmith\"}"),
        ev(S("ruined_portal_mountain")),
        ev("fill ~-5 ~-1 ~-5 ~5 ~2 ~5 oak_leaves[persistent=true] hollow", "fill ~-2 ~ ~-4 ~-2 ~2 ~2 oak_leaves[persistent=true]", "fill ~2 ~ ~-2 ~2 ~2 ~4 oak_leaves[persistent=true]", "fill ~-4 ~ ~3 ~0 ~2 ~3 oak_leaves[persistent=true]"),
        ev("fill ~-4 ~ ~-4 ~4 ~ ~4 pumpkin replace air", "setblock ~ ~ ~ air"),
        ev("fill ~2 ~-2 ~2 ~8 ~-1 ~8 stone", "fill ~4 ~-2 ~4 ~6 ~-1 ~6 magma_block", "setblock ~5 ~ ~5 obsidian", "setblock ~5 ~-1 ~5 obsidian")
    };

    // ===================== 90 EVENEMENTS LEGENDAIRES =====================
    static final String[][] LEGEND = {
        // A. Grandes structures (1-20)
        ev(S("village_plains")), ev(S("mansion")), ev(S("ancient_city")), ev(S("monument")), ev(S("fortress")),
        ev(S("bastion_remnant")), ev(S("jungle_pyramid")), ev(S("desert_pyramid")), ev(S("ruined_portal")), ev(S("mineshaft")),
        ev(S("end_city")), ev(S("shipwreck")), ev(S("pillager_outpost")), ev(S("igloo")), ev(S("buried_treasure")),
        ev(S("ocean_ruin_cold")), ev(S("swamp_hut")), ev("place feature minecraft:fossil_upper"),
        ev("fill ~3 ~-1 ~-2 ~7 ~0 ~2 sandstone", "fill ~4 ~0 ~-1 ~6 ~0 ~1 water", "fill ~3 ~1 ~-2 ~7 ~1 ~2 sandstone_slab"),
        ev(S("village_plains"), "execute positioned ~200 ~ ~ run place structure minecraft:village_desert", "execute positioned ~-200 ~ ~ run place structure minecraft:village_snowy"),
        // B. Recompenses (21-35)
        ev("CHEST:2,0,0:diamond*64|diamond*64|diamond_block*16|emerald*64", "CHEST:2,0,2:diamond*64|diamond*64|diamond_block*16", "CHEST:2,0,-2:diamond*64|diamond*64|diamond_block*16"),
        ev("CHEST:2,0,0:gold_block*64|gold_block*64|gold_ingot*64|golden_apple*16|golden_carrot*64", "CHEST:2,0,2:gold_block*64|gold_ingot*64|raw_gold*64"),
        ev("CHEST:2,0,0:emerald_block*32|emerald*64|diamond*64|diamond_ore*32|gold_ore*32|iron_ore*32|lapis_ore*32|redstone_ore*32"),
        ev("CHEST:2,0,0:netherite_ingot*8|netherite_block*2|netherite_scrap*16|netherite_sword*1*" + E("sharpness:5,looting:3") + "|netherite_pickaxe*1*" + E("efficiency:5,fortune:3") + "|netherite_axe*1|netherite_shovel*1|netherite_helmet*1|netherite_chestplate*1|netherite_leggings*1|netherite_boots*1"),
        ev("CHEST:2,0,0:diamond_helmet*1*" + E("protection:4,unbreaking:3") + "|diamond_chestplate*1*" + E("protection:4,unbreaking:3") + "|diamond_leggings*1*" + E("protection:4,unbreaking:3") + "|diamond_boots*1*" + E("protection:4,unbreaking:3") + "|diamond_sword*1*" + E("sharpness:5,unbreaking:3") + "|diamond_pickaxe*1*" + E("efficiency:5,unbreaking:3") + "|diamond_axe*1|diamond_shovel*1|bow*1*" + E("power:5,infinity:1") + "|shield*1|arrow*64"),
        ev("CHEST:2,0,0:" + B("mending:1") + "|" + B("unbreaking:3") + "|" + B("fortune:3") + "|" + B("silk_touch:1") + "|" + B("sharpness:5") + "|" + B("protection:4") + "|" + B("efficiency:5") + "|" + B("looting:3") + "|" + B("power:5") + "|" + B("thorns:3") + "|" + B("feather_falling:4") + "|" + B("respiration:3") + "|" + B("depth_strider:3") + "|" + B("frost_walker:2") + "|" + B("soul_speed:3") + "|" + B("swift_sneak:3") + "|" + B("infinity:1") + "|" + B("fire_aspect:2") + "|" + B("sweeping:3") + "|" + B("loyalty:3") + "|" + B("riptide:3") + "|" + B("channeling:1") + "|" + B("impaling:5") + "|" + B("multishot:1") + "|" + B("quick_charge:3") + "|" + B("luck_of_the_sea:3") + "|" + B("lure:3")),
        ev("CHEST:2,0,0:nether_star*1|dragon_egg*1|elytra*1|totem_of_undying*2|heart_of_the_sea*1|trident*1|conduit*1|enchanted_golden_apple*4|echo_shard*4|netherite_ingot*2|shulker_box*1|beacon*1|music_disc_pigstep*1|music_disc_otherside*1|sponge*4|recovery_compass*1|ender_chest*1"),
        ev("CHEST:2,0,0:trident*1*" + E("riptide:3,unbreaking:3") + "|conduit*2|heart_of_the_sea*2|prismarine_shard*64|prismarine_crystals*64|sea_lantern*32|nautilus_shell*4|turtle_helmet*1|sponge*16|tropical_fish_bucket*2"),
        ev("CHEST:2,0,0:totem_of_undying*1|totem_of_undying*1|totem_of_undying*1|totem_of_undying*1|totem_of_undying*1|totem_of_undying*1|totem_of_undying*1|totem_of_undying*1"),
        ev("CHEST:2,0,0:elytra*1*" + E("unbreaking:3,mending:1") + "|dragon_head*1|dragon_egg*1|end_crystal*4|shulker_box*2|ender_chest*2|ender_eye*16|ender_pearl*16|chorus_fruit*32|purpur_block*64|end_rod*32"),
        ev("CHEST:2,0,0:bread*64|cooked_beef*64|cooked_porkchop*64|cooked_chicken*64|baked_potato*64|golden_carrot*64|pumpkin_pie*64|cooked_salmon*64|honey_bottle*16", "CHEST:2,0,2:cake*1|golden_apple*32|enchanted_golden_apple*8|apple*64|melon_slice*64|sweet_berries*64|glow_berries*64|cookie*64|mushroom_stew*1"),
        ev("CHEST:2,0,0:" + P("strong_healing") + "|" + P("strong_swiftness") + "|" + P("strong_strength") + "|" + P("long_fire_resistance") + "|" + P("long_night_vision") + "|" + P("long_water_breathing") + "|" + P("long_regeneration") + "|" + P("long_slow_falling") + "|" + P("strong_leaping") + "|" + P("long_invisibility") + "|" + P("long_turtle_master") + "|brewing_stand*1|blaze_powder*64|nether_wart*64"),
        ev("CHEST:2,0,0:stone_bricks*64|quartz_block*64|glass*64|oak_planks*64|bricks*64|terracotta*64|white_concrete*64|sandstone*64|deepslate_bricks*64|spruce_planks*64", "CHEST:2,0,2:prismarine_bricks*64|purpur_block*64|copper_block*64|smooth_stone*64|polished_andesite*64|lantern*32|ladder*64|oak_door*16"),
        ev("CHEST:2,0,0:raw_iron*64|raw_gold*64|raw_copper*64|coal*64|lapis_lazuli*64|redstone*64|diamond*32|emerald*32|quartz*64|ancient_debris*4|amethyst_shard*64", "CHEST:2,0,2:iron_block*16|gold_block*16|copper_block*16|coal_block*16|lapis_block*16|redstone_block*16|diamond_block*4|emerald_block*4"),
        ev("CHEST:2,0,0:emerald*64|bookshelf*16|iron_pickaxe*1*" + E("efficiency:3") + "|saddle*1|bell*1|compass*1|clock*1|name_tag*8|map*1|lantern*8|lead*8|bucket*2|shears*1|fishing_rod*1|bow*1|arrow*64|bread*32|glass_bottle*16|lectern*1|cartography_table*1"),
        // C. Catastrophes (36-50)
        ev(ANVIL_RAIN), ev("fill ~-8 ~ ~-8 ~8 ~5 ~8 water replace air"),
        ev("fill ~-6 ~ ~-6 ~6 ~ ~6 fire replace air", "REP:6:6:summon lightning_bolt {x} ~ {z}"),
        ev("weather thunder 6000", "REP:8:8:summon lightning_bolt {x} ~ {z}"),
        ev("fill ~-6 ~-1 ~-6 ~6 ~-4 ~6 air replace dirt", "fill ~-6 ~-1 ~-6 ~6 ~-4 ~6 air replace grass_block", "fill ~-6 ~-1 ~-6 ~6 ~-4 ~6 air replace stone"),
        ev("REP:10:7:summon tnt {x} ~14 {z} {fuse:60}"),
        ev("time set midnight", "effect give @p darkness 40 0", "effect give @p blindness 15 0", "REP:6:8:summon zombie {x} ~ {z}"),
        ev("fill ~-3 ~ ~-3 ~3 ~4 ~3 packed_ice hollow", "damage @p 4 minecraft:freeze"),
        ev("effect give @p nausea 20 0", "effect give @p levitation 6 1", "effect give @p slowness 20 1", "effect give @p blindness 8 0", "REP:6:5:summon creeper {x} ~ {z}"),
        ev("summon creeper ~3 ~ ~ {powered:1b}", "summon creeper ~-3 ~ ~ {powered:1b}", "summon creeper ~ ~ ~3 {powered:1b}", "summon creeper ~ ~ ~-3 {powered:1b}"),
        ev("REP:6:4:summon phantom {x} ~8 {z}"),
        ev("effect give @p levitation 2 9 true"),
        ev("REP:20:6:summon bat {x} ~3 {z}", "REP:10:3:summon silverfish {x} ~ {z}"),
        ev("effect give @p poison 20 1", "effect give @p hunger 30 2", "effect give @p weakness 60 1", "effect give @p slowness 40 1"),
        ev("summon ender_dragon ~ ~30 ~"),
        // D. Mobs et boss (51-70)
        ev("summon wither ~5 ~ ~"), ev("summon warden ~6 ~ ~"),
        ev("REP:5:6:summon pillager {x} ~ {z}", "summon ravager ~6 ~ ~", "REP:2:6:summon vindicator {x} ~ {z}"),
        ev("REP:3:6:summon evoker {x} ~ {z}"), ev("REP:5:5:summon iron_golem {x} ~ {z}"),
        ev("summon skeleton_horse ~ ~ ~ {SkeletonTrap:1b}", "summon lightning_bolt ~4 ~ ~"),
        ev("REP:6:4:summon vex {x} ~2 {z}"), ev("REP:8:5:summon wolf {x} ~ {z}"),
        ev("summon slime ~5 ~ ~ {Size:6}"), ev("summon magma_cube ~5 ~ ~ {Size:5}"),
        ev("REP:4:6:summon shulker {x} ~ {z}"), ev("summon ghast ~ ~12 ~"),
        ev("REP:3:5:summon blaze {x} ~ {z}"),
        ev("REP:4:5:summon hoglin {x} ~ {z}", "REP:2:5:summon piglin_brute {x} ~ {z}"),
        ev("summon giant ~8 ~ ~"), ev("REP:6:8:summon enderman {x} ~ {z}"), ev("summon elder_guardian ~5 ~ ~"),
        ev("REP:10:6:summon llama {x} ~ {z}"), ev("REP:10:6:summon mooshroom {x} ~ {z}"),
        ev("summon allay ~2 ~ ~", "summon axolotl ~-2 ~ ~", "summon frog ~ ~ ~2", "summon goat ~ ~ ~-2", "summon fox ~3 ~ ~3", "summon panda ~-3 ~ ~3", "summon parrot ~3 ~2 ~-3", "summon polar_bear ~-3 ~ ~-3"),
        // E. Dimensions, constructions, mecanismes (71-90)
        ev("fill ~3 ~ ~ ~6 ~4 ~ obsidian", "fill ~4 ~1 ~ ~5 ~3 ~ nether_portal[axis=x]"),
        ev("fill ~2 ~-1 ~-1 ~4 ~-1 ~1 end_portal",
           "setblock ~2 ~-1 ~-2 end_portal_frame[eye=true,facing=south]", "setblock ~3 ~-1 ~-2 end_portal_frame[eye=true,facing=south]", "setblock ~4 ~-1 ~-2 end_portal_frame[eye=true,facing=south]",
           "setblock ~2 ~-1 ~2 end_portal_frame[eye=true,facing=north]", "setblock ~3 ~-1 ~2 end_portal_frame[eye=true,facing=north]", "setblock ~4 ~-1 ~2 end_portal_frame[eye=true,facing=north]",
           "setblock ~1 ~-1 ~-1 end_portal_frame[eye=true,facing=east]", "setblock ~1 ~-1 ~0 end_portal_frame[eye=true,facing=east]", "setblock ~1 ~-1 ~1 end_portal_frame[eye=true,facing=east]",
           "setblock ~5 ~-1 ~-1 end_portal_frame[eye=true,facing=west]", "setblock ~5 ~-1 ~0 end_portal_frame[eye=true,facing=west]", "setblock ~5 ~-1 ~1 end_portal_frame[eye=true,facing=west]"),
        ev("fill ~-7 ~-1 ~-7 ~7 ~6 ~7 obsidian hollow", "REP:6:5:summon skeleton {x} ~ {z}", "REP:4:5:summon zombie {x} ~ {z}", "CHEST:0,0,6:diamond*16|golden_apple*8"),
        ev("fill ~-1 ~19 ~-1 ~1 ~19 ~1 stone_bricks", "setblock ~3 ~19 ~ stone_bricks", "setblock ~6 ~20 ~ stone_bricks", "setblock ~9 ~19 ~ stone_bricks", "setblock ~12 ~20 ~ stone_bricks",
           "fill ~14 ~19 ~-1 ~16 ~19 ~1 gold_block", "CHEST:15,20,0:diamond*16|emerald*32|golden_apple*4", "tp @p ~ ~20 ~"),
        ev("fill ~-2 ~-4 ~-2 ~2 ~-1 ~2 lava"),
        ev("fill ~-5 ~-2 ~-5 ~5 ~-2 ~5 tnt", "summon tnt ~ ~-1 ~ {fuse:60}"),
        ev("fill ~-3 ~30 ~-3 ~3 ~30 ~3 grass_block", "fill ~-2 ~29 ~-2 ~2 ~29 ~2 dirt", "CHEST:2,31,0:diamond*32|golden_apple*8|elytra*1", "tp @p ~ ~31 ~"),
        ev("fill ~-4 ~-13 ~-4 ~4 ~-6 ~4 stone_bricks hollow", "CHEST:0,-12,3:diamond*16|iron_ingot*64|golden_apple*4", "CHEST:3,-12,0:emerald*32|gold_ingot*64|enchanted_golden_apple*1", "tp @p ~ ~-11 ~"),
        ev("fill ~3 ~-1 ~3 ~5 ~14 ~5 cobblestone hollow", "CHEST:4,15,4:diamond*32|emerald*32|golden_apple*8"),
        ev("fill ~3 ~ ~-3 ~9 ~0 ~3 gold_block", "fill ~4 ~1 ~-2 ~8 ~1 ~2 gold_block", "fill ~5 ~2 ~-1 ~7 ~2 ~1 gold_block", "CHEST:6,3,0:gold_block*64|diamond*32|emerald*32"),
        ev("fill ~-3 ~-1 ~-3 ~3 ~-1 ~3 moss_block", "fill ~-3 ~ ~-3 ~3 ~ ~3 flowering_azalea replace air", "REP:6:3:summon bee {x} ~1 {z}"),
        ev("REP:12:5:summon firework_rocket {x} ~ {z} {LifeTime:30,FireworksItem:{id:\"minecraft:firework_rocket\",count:1,components:{\"minecraft:fireworks\":{flight_duration:1,explosions:[{shape:\"large_ball\",colors:[I;16711680,65280,255]}]}}}}", "DROP:cake*3|golden_apple*4"),
        ev("fill ~-6 ~-1 ~-6 ~6 ~-1 ~6 netherrack", "fill ~-6 ~ ~-6 ~6 ~ ~6 fire replace air", "REP:3:5:summon zombified_piglin {x} ~ {z}", "summon ghast ~ ~10 ~", "setblock ~3 ~ ~3 lava"),
        ev("fill ~-6 ~-1 ~-6 ~6 ~-1 ~6 end_stone", "setblock ~4 ~-1 ~ obsidian", "summon end_crystal ~4 ~ ~", "REP:4:6:summon enderman {x} ~ {z}"),
        ev("fill ~-6 ~-1 ~-6 ~6 ~-1 ~6 sand", "setblock ~3 ~ ~3 cactus", "setblock ~-3 ~ ~-2 cactus", "REP:4:6:summon husk {x} ~ {z}"),
        ev("fill ~-6 ~-1 ~-6 ~6 ~-1 ~6 packed_ice", "summon polar_bear ~4 ~ ~", "summon polar_bear ~-4 ~ ~", "REP:3:6:summon stray {x} ~ {z}"),
        ev("effect give @p regeneration 300 1", "effect give @p resistance 300 1", "effect give @p speed 300 1", "effect give @p haste 300 1", "effect give @p strength 300 1", "time set day", "weather clear", "DROP:golden_apple*5"),
        ev("effect give @p unluck 600 0", "effect give @p weakness 300 1", "effect give @p slowness 300 1", "effect give @p mining_fatigue 300 1", "effect give @p hunger 300 1", "time set night"),
        ev("DROP:netherite_block*1|netherite_ingot*4|diamond_block*8", "summon creeper ~2 ~ ~ {powered:1b,Fuse:20,ignited:1b}"),
        ev("CHEST:2,0,0:netherite_ingot*16|netherite_block*4|diamond_block*32|enchanted_golden_apple*16|totem_of_undying*4|elytra*1*" + E("unbreaking:3,mending:1") + "|nether_star*2|beacon*1|ender_pearl*16",
           "CHEST:2,0,2:netherite_helmet*1*" + E("protection:4,unbreaking:3,mending:1") + "|netherite_chestplate*1*" + E("protection:4,unbreaking:3,mending:1") + "|netherite_leggings*1*" + E("protection:4,unbreaking:3,mending:1") + "|netherite_boots*1*" + E("protection:4,unbreaking:3,mending:1,feather_falling:4") + "|netherite_sword*1*" + E("sharpness:5,looting:3,mending:1") + "|netherite_pickaxe*1*" + E("efficiency:5,fortune:3,mending:1") + "|netherite_axe*1*" + E("efficiency:5,mending:1"),
           "CHEST:2,0,-2:" + B("mending:1") + "|" + B("fortune:3") + "|" + B("looting:3") + "|" + B("protection:4") + "|" + B("sharpness:5") + "|" + B("efficiency:5") + "|" + B("unbreaking:3"))
    };
}
