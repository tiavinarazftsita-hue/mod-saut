package com.lucky.mod;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

public class LuckyEvents {

    public static void trigger(ServerLevel lvl, BlockPos pos, ServerPlayer p, boolean legendary) {
        String[] ev;
        if (legendary) {
            int i = lvl.getRandom().nextInt(LuckyData.LEGEND.length);
            ev = LuckyData.LEGEND[i];
            cmd(lvl, p, "title @p actionbar {\"text\":\"\u2726 \u00c9v\u00e9nement l\u00e9gendaire n\u00b0" + (i + 1) + " \u2726\",\"color\":\"light_purple\"}");
        } else {
            int roll = lvl.getRandom().nextInt(100);
            if (roll < 35) ev = new String[]{"DROP:" + LuckyData.BONUS[lvl.getRandom().nextInt(LuckyData.BONUS.length)]};
            else if (roll < 65) ev = new String[]{"DROP:" + LuckyData.MALUS[lvl.getRandom().nextInt(LuckyData.MALUS.length)]};
            else ev = LuckyData.CLASSIC[lvl.getRandom().nextInt(LuckyData.CLASSIC.length)];
        }
        for (String line : ev) exec(lvl, p, pos, line);
    }

    private static void exec(ServerLevel lvl, ServerPlayer p, BlockPos pos, String line) {
        try {
            if (line.startsWith("DROP:")) {
                for (String e : line.substring(5).split("\\|")) {
                    cmd(lvl, p, "summon item " + (pos.getX() + 0.5) + " " + (pos.getY() + 0.5) + " " + (pos.getZ() + 0.5)
                            + " {Item:" + item(e, -1) + ",PickupDelay:10}");
                }
            } else if (line.startsWith("REP:")) {
                String[] a = line.split(":", 4);
                int n = Integer.parseInt(a[1]);
                int rad = Integer.parseInt(a[2]);
                for (int i = 0; i < n; i++) {
                    String c = a[3].replace("{x}", "~" + (lvl.getRandom().nextInt(2 * rad + 1) - rad))
                            .replace("{z}", "~" + (lvl.getRandom().nextInt(2 * rad + 1) - rad));
                    cmd(lvl, p, c);
                }
            } else if (line.startsWith("CHEST:")) {
                String[] a = line.split(":", 3);
                String[] d = a[1].split(",");
                cmd(lvl, p, "setblock ~" + d[0] + " ~" + d[1] + " ~" + d[2] + " chest{Items:" + items(a[2]) + "}");
            } else {
                cmd(lvl, p, line);
            }
        } catch (Exception ex) {
            LuckyMod.LOGGER.warn("Lucky event error on '{}': {}", line, ex.toString());
        }
    }

    private static void cmd(ServerLevel lvl, ServerPlayer p, String line) {
        CommandSourceStack src = lvl.getServer().createCommandSourceStack().withLevel(lvl).withPosition(p.position()).withSuppressedOutput();
        lvl.getServer().getCommands().performPrefixedCommand(src, line);
    }

    private static String items(String list) {
        String[] e = list.split("\\|");
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < Math.min(e.length, 27); i++) {
            if (i > 0) b.append(',');
            b.append(item(e[i], i));
        }
        return b.append(']').toString();
    }

    // "id*count*tag" -> SNBT
    private static String item(String e, int slot) {
        String[] a = e.split("\\*", 3);
        StringBuilder b = new StringBuilder("{");
        if (slot >= 0) b.append("Slot:").append(slot).append("b,");
        b.append("id:\"minecraft:").append(a[0]).append("\",count:").append(a.length > 1 ? a[1] : "1");
        if (a.length > 2) b.append(",components:").append(a[2]);
        return b.append('}').toString();
    }
}
