package com.lucky.mod;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.bus.BusGroup;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

@Mod(LuckyMod.MODID)
public class LuckyMod {
    public static final String MODID = "luckyblocksmod";
    public static final Logger LOGGER = LogUtils.getLogger();
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    static ResourceKey<Block> blockKey(String n) { return ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(MODID, n)); }
    static ResourceKey<Item> itemKey(String n) { return ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MODID, n)); }

    public static final RegistryObject<Block> LUCKY = BLOCKS.register("lucky_block", () -> new LuckyBlock(false, blockKey("lucky_block")));
    public static final RegistryObject<Block> LEGENDARY = BLOCKS.register("legendary_lucky_block", () -> new LuckyBlock(true, blockKey("legendary_lucky_block")));
    public static final RegistryObject<Item> LUCKY_ITEM = ITEMS.register("lucky_block",
            () -> new BlockItem(LUCKY.get(), new Item.Properties().setId(itemKey("lucky_block")).useBlockDescriptionPrefix()));
    public static final RegistryObject<Item> LEGENDARY_ITEM = ITEMS.register("legendary_lucky_block",
            () -> new BlockItem(LEGENDARY.get(), new Item.Properties().setId(itemKey("legendary_lucky_block")).useBlockDescriptionPrefix()));
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("lucky_tab", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.luckyblocksmod"))
            .icon(() -> new ItemStack(LEGENDARY_ITEM.get()))
            .displayItems((params, out) -> { out.accept(LUCKY_ITEM.get()); out.accept(LEGENDARY_ITEM.get()); })
            .build());

    public LuckyMod(FMLJavaModLoadingContext context) {
        BusGroup bus = context.getModBusGroup();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
