package com.lucky.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;

public class LuckyBlock extends Block {
    private final boolean legendary;

    public LuckyBlock(boolean legendary, ResourceKey<Block> key) {
        super(BlockBehaviour.Properties.of().setId(key)
                .mapColor(legendary ? MapColor.COLOR_PURPLE : MapColor.GOLD)
                .strength(0.5F).sound(SoundType.WOOD).lightLevel(s -> legendary ? 10 : 0));
        this.legendary = legendary;
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide() && level instanceof ServerLevel sl && player instanceof ServerPlayer sp) {
            LuckyEvents.trigger(sl, pos, sp, legendary);
        }
        return super.playerWillDestroy(level, pos, state, player);
    }
}
